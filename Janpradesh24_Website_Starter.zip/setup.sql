-- जनप्रदेश 24: Supabase SQL setup
-- पहले Supabase Dashboard > SQL Editor में यह पूरा SQL चलाएँ।
create table if not exists public.news (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  content text not null,
  category text default 'खबर',
  image_url text,
  published boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.news enable row level security;

-- सभी visitors केवल published खबरें पढ़ सकते हैं।
drop policy if exists "Public can read published news" on public.news;
create policy "Public can read published news"
on public.news for select
to anon, authenticated
using (published = true);

-- नीचे janpradesh24@gmail.com को अपने Admin login email से बदलें।
-- केवल इसी email को खबर जोड़ने/बदलने/डिलीट करने की अनुमति मिलेगी।
drop policy if exists "Admin can manage news" on public.news;
create policy "Admin can manage news"
on public.news for all
to authenticated
using ((auth.jwt() ->> 'email') = 'janpradesh24@gmail.com')
with check ((auth.jwt() ->> 'email') = 'janpradesh24@gmail.com');

-- Admin को unpublished drafts भी देखने देने के लिए:
drop policy if exists "Admin can read all news" on public.news;
create policy "Admin can read all news"
on public.news for select
to authenticated
using ((auth.jwt() ->> 'email') = 'janpradesh24@gmail.com');
